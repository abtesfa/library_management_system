# Update notes – profile pictures and library logo

Before starting the updated backend, run `sql/profile_pictures_and_library_logo.sql` once against the existing MySQL database. It adds nullable `LONGBLOB` columns to `staff`, `student`, and `library_settings`. Existing rows remain valid and will show initials / the book icon until images are uploaded.

Image uploads are limited to 5 MB and accept JPEG, PNG, and WEBP. Endpoints:
- `PUT /api/profile-pictures/{role}/{id}` multipart field `file` (`STUDENT`, `ADMIN`, or `LIBRARIAN`)
- `GET /api/profile-pictures/{role}/{id}`
- `PUT /api/settings/logo` multipart field `file`
- `GET /api/settings/logo`

The settings JSON includes the logo as Base64 in `libraryLogo` for the existing Flutter settings loader.
