# Update notes – requested UI changes

- Profile photos now upload to the backend and are stored in the `staff` / `student` BLOB columns. The signed-in user's photo is loaded when entering the portal.
- The three change-password fields now have visibility toggles.
- Reader catalogue keeps its existing card layout and displays up to six books per page with Previous / Next controls.
- Search now sits above a category dropdown; selecting a category filters the visible books. `Recommended for You` currently preserves the existing general catalogue selection because the project does not currently expose a recommendation-ranking service.
- LMS Settings > Library Information has an Upload Logo action. The logo is read from `library_settings.library_logo` and shown in the landing header and signed-in top bar.
